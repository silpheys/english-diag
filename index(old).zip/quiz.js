// ─── НАСТРОЙКА ───────────────────────────────────────────────
// После деплоя Apps Script вставьте сюда URL Web App
const WEB_APP_URL = "https://script.google.com/macros/s/AKfycbxeRCT95iEpR8O-EZuN-cMXxZ_s22JcvxmfEt-pKLflLefQVMXrPFrzIuHyFQmR4RjE/exec";

let currentStep = 1;
const totalSteps = 6;

function startQuiz() {
  document.getElementById('hero').style.display = 'none';
  document.getElementById('quizWrap').classList.add('active');
  updateProgress(1);
}

function updateProgress(step) {
  const pct = ((step - 1) / totalSteps) * 100;
  document.getElementById('progressFill').style.width = pct + '%';
  document.getElementById('stepLabel').textContent = `Шаг ${step} из ${totalSteps}`;
}

function goNext(step) {
  if (step === 1 && !document.getElementById('childName').value.trim()) {
    document.getElementById('childName').focus();
    return;
  }
  document.getElementById('slide-' + step).classList.remove('active');
  currentStep = step + 1;
  document.getElementById('slide-' + currentStep).classList.add('active');
  updateProgress(currentStep);
  window.scrollTo(0, 0);
}

function goBack(step) {
  document.getElementById('slide-' + step).classList.remove('active');
  currentStep = step - 1;
  document.getElementById('slide-' + currentStep).classList.add('active');
  updateProgress(currentStep);
  window.scrollTo(0, 0);
}

// ─── ОДИНОЧНЫЙ ВЫБОР ─────────────────────────────────────────
function selectOpt(btn, groupId, nextBtnId) {
  document.querySelectorAll('#' + groupId + ' .opt:not(.multi)').forEach(b => b.classList.remove('selected'));
  btn.classList.add('selected');
  if (nextBtnId) document.getElementById(nextBtnId).disabled = false;
}

// ─── МНОЖЕСТВЕННЫЙ ВЫБОР (toggle) ────────────────────────────
function toggleOpt(btn, groupId) {
  btn.classList.toggle('selected');
}

// ─── ПОЛУЧЕНИЕ ЗНАЧЕНИЙ ──────────────────────────────────────

// Одиночный выбор — возвращает текст выбранной кнопки
function getSelected(groupId) {
  const sel = document.querySelector('#' + groupId + ' .opt.selected:not(.multi)');
  if (!sel) return 'не указано';
  const strong = sel.querySelector('strong');
  const span   = sel.querySelector('span');
  return strong ? strong.textContent + (span ? ' — ' + span.textContent : '') : '';
}

// Множественный выбор — возвращает все выбранные через запятую
function getMultiSelected(groupId) {
  const selected = document.querySelectorAll('#' + groupId + ' .opt.multi.selected');
  if (!selected.length) return 'не указано';
  return Array.from(selected).map(btn => {
    const strong = btn.querySelector('strong');
    return strong ? strong.textContent : '';
  }).filter(Boolean).join(', ');
}

// Проверка: хотя бы один вариант выбран (работает для обоих типов)
function hasSelection(groupId) {
  return !!document.querySelector('#' + groupId + ' .opt.selected');
}

// ─── ПРОВЕРКИ БЛОКОВ ─────────────────────────────────────────

function checkBlock2() {
  document.getElementById('next2').disabled = !(
    hasSelection('opts-interest') &&
    hasSelection('opts-screen') &&
    hasSelection('opts-reaction') &&
    hasSelection('opts-type')
  );
}

function checkBlock3() {
  document.getElementById('next3').disabled = !(
    hasSelection('opts-dream') &&
    hasSelection('opts-tech') &&
    hasSelection('opts-exp') &&
    hasSelection('opts-roblox')
  );
}

function checkBlock4() {
  document.getElementById('next4').disabled = !(
    hasSelection('opts-resilience') &&
    hasSelection('opts-learnstyle') &&
    hasSelection('opts-math') &&
    hasSelection('opts-teamwork')
  );
}

function checkBlock5() {
  document.getElementById('next5').disabled = !(
    hasSelection('opts-goal') &&
    hasSelection('opts-parent-goal') &&
    hasSelection('opts-speed')
  );
}

// ─── ОТПРАВКА ────────────────────────────────────────────────

async function submitQuiz() {
  const parentName  = document.getElementById('parentName').value.trim();
  const parentEmail = document.getElementById('parentEmail').value.trim();
  const errorMsg    = document.getElementById('errorMsg');

  if (!parentName || !parentEmail) {
    errorMsg.style.display = 'block';
    return;
  }
  errorMsg.style.display = 'none';

  const data = {
    childName:    document.getElementById('childName').value.trim(),
    childAge:     document.getElementById('ageRange').value,
    childClass:   document.getElementById('childClass').value.trim() || 'не указан',
    // Блок 2
    interest:     getMultiSelected('opts-interest'),
    screenTime:   getSelected('opts-screen'),
    reaction:     getSelected('opts-reaction'),
    childType:    getSelected('opts-type'),
    // Блок 3
    dreamProject: getSelected('opts-dream'),
    techAttitude: getSelected('opts-tech'),
    experience:   getSelected('opts-exp'),
    robloxExp:    getSelected('opts-roblox'),
    // Блок 4 — диагностика
    resilience:   getSelected('opts-resilience'),
    learnStyle:   getSelected('opts-learnstyle'),
    mathLevel:    getSelected('opts-math'),
    teamwork:     getSelected('opts-teamwork'),
    // Блок 5
    itGoal:       getMultiSelected('opts-goal'),
    parentGoal:   getMultiSelected('opts-parent-goal'),
    resultSpeed:  getSelected('opts-speed'),
    // Блок 6
    parentName,
    parentEmail,
    notes: document.getElementById('notes').value.trim() || 'нет',
  };

  document.getElementById('quizWrap').classList.remove('active');
  document.getElementById('sendingScreen').classList.add('active');

  try {
    await fetch(WEB_APP_URL, {
      method: 'POST',
      mode: 'no-cors',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
  } catch(e) {
    console.log('Sent (no-cors mode)');
  }

  setTimeout(() => {
    document.getElementById('sendingScreen').classList.remove('active');
    document.getElementById('successEmail').textContent = parentEmail;
    document.getElementById('successScreen').classList.add('active');
  }, 2500);
}

// ─── СБРОС ───────────────────────────────────────────────────

function restart() {
  document.getElementById('successScreen').classList.remove('active');
  document.getElementById('hero').style.display = 'flex';

  document.getElementById('childName').value   = '';
  document.getElementById('childClass').value  = '';
  document.getElementById('parentName').value  = '';
  document.getElementById('parentEmail').value = '';
  document.getElementById('notes').value       = '';
  document.getElementById('ageRange').value    = 10;
  document.getElementById('ageDisplay').textContent = '10 лет';

  document.querySelectorAll('.opt').forEach(b => b.classList.remove('selected'));
  ['next2','next3','next4','next5'].forEach(id => document.getElementById(id).disabled = true);

  document.querySelectorAll('.quiz-slide').forEach(s => s.classList.remove('active'));
  document.getElementById('slide-1').classList.add('active');
  document.getElementById('quizWrap').classList.remove('active');
  currentStep = 1;
  updateProgress(1);
}